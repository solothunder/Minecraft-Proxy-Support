# Minecraft-Proxy-Support
Minecraft-Proxy-Support Program

このソフトのダウンロードをしていただきありがとうございます。
こちらのソフトはVPSなどのコンソール環境でも使えるCUIの「Minecraft-Proxy-Support」です。
構成としては
Nginx 1.18.0でプロキシを立てています。
私の開発環境　兼　確認環境ではCPU AMD64 (64Bit)/Intel x64を使っていますなのでARM系CPUでは動かないかもしれません。

このプログラムはaptを使っています。なので
sudo yum install apt

などでaptを入れます。

Python3とPIP3が必要になるので
入っていなければ
sudo apt install python3 python3-pip
などでPython3とPIP3を入れます。
これで環境は揃ったと思われます。

もし問題が起こったら
Discord : solo-thunder#0581
メール : webmaster@solo-thunder.f5.si
にDM・メールで送ってください。
※迷惑メールはご遠慮ください。※
